//
//  AppDelegate.h
//  test
//
//  Created by 李志权 on 2017/6/13.
//  Copyright © 2017年 李志权. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

